# License decision required before public release

Copyright 2026 Anonymous Author(s). All rights reserved unless and until the author selects an explicit license after the review anonymity period.

The reproduction package can be privately supplied to reviewers under the conference review process. Before public archival release, the author should choose and add an explicit software/data license compatible with the licenses and terms of all dependencies and cited datasets. This file is not an open-source license grant.
