from __future__ import annotations

from real_fault_pilot import build_replays


def test_patch_derived_buggy_versions_fail_and_fixed_versions_pass():
    for replay in build_replays():
        for seed in (17, 43):
            _, buggy_passed = replay.probe(False, seed)
            _, fixed_passed = replay.probe(True, seed)
            assert not buggy_passed, replay.fault_id
            assert fixed_passed, replay.fault_id


def test_replay_ids_and_commit_urls_are_unique():
    replays = build_replays()
    assert len(replays) == len({replay.fault_id for replay in replays})
    assert len(replays) == len({replay.commit_url for replay in replays})
