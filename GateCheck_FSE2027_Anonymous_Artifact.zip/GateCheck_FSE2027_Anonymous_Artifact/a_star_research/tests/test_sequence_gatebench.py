from __future__ import annotations

import pandas as pd

from sequence_gatebench import Thresholds, build_cases, run_probe, summarize


def test_sequence_benchmark_detects_mutants_without_control_alarms():
    rows = [
        run_probe(case, seed=seed, length=7, batch=4, distribution="gaussian", thresholds=Thresholds())
        for case in build_cases(features=(8,))
        for seed in (17, 43)
    ]
    summary, _ = summarize(pd.DataFrame(rows), Thresholds())
    assert summary["all_cases_correct"]


def test_sequence_case_ids_are_unique():
    cases = build_cases()
    assert len(cases) == len({case.case_id for case in cases})
