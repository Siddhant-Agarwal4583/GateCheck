from __future__ import annotations

import pandas as pd

from gatecheck import Thresholds, build_cases, run_probe, summarize


def test_benchmark_detects_all_prespecified_mutants_without_control_alarms():
    thresholds = Thresholds()
    rows = []
    for case in build_cases(channels=(4,)):
        for seed in (17, 43):
            rows.append(
                run_probe(
                    case,
                    seed=seed,
                    height=8,
                    width=9,
                    batch=4,
                    distribution="gaussian",
                    thresholds=thresholds,
                )
            )
    report = summarize(pd.DataFrame(rows), thresholds)["summary"]
    assert report["all_cases_correct"]
    assert report["recall"] == 1.0
    assert report["specificity"] == 1.0


def test_case_ids_are_unique():
    cases = build_cases()
    assert len(cases) == len({case.case_id for case in cases})
