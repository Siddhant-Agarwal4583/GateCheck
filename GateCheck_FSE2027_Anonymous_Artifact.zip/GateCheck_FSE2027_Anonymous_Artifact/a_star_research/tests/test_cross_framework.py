from __future__ import annotations

from cross_framework_check import CASES, run_jax, run_torch


def test_torch_and_jax_agree_on_contract_decisions():
    for case, expected_fault in CASES.items():
        torch_row = run_torch(case, 17)
        jax_row = run_jax(case, 17)
        assert torch_row["detected_fault"] == expected_fault
        assert jax_row["detected_fault"] == expected_fault
        assert torch_row["detected_fault"] == jax_row["detected_fault"]
