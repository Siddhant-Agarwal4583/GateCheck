#!/usr/bin/env bash
set -euo pipefail

export PYTHONPATH="a_star_research/src"
export MPLBACKEND="Agg"

python -m pytest -q a_star_research/tests
python a_star_research/src/gatecheck.py --output a_star_research/results
python a_star_research/src/sequence_gatebench.py --output a_star_research/results
python a_star_research/src/real_fault_pilot.py --output a_star_research/results
python a_star_research/src/cross_framework_check.py --output a_star_research/results
python a_star_research/src/analyze_gatebench.py
python a_star_research/src/analyze_extended.py
python a_star_research/src/reanalyze_case_study.py
