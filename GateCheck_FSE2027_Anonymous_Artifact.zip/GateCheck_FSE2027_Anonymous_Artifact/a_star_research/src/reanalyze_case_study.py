from __future__ import annotations

from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from scipy.stats import wilcoxon


SOURCE = Path("research/results")
RESULTS = Path("a_star_research/results")
FIGURES = Path("a_star_research/figures")
VARIANTS = ["plain", "sigmoid", "integrity"]
CONDITIONS = ["clean", "noise", "bias"]
SEEDS = [17, 43, 101]


def holm(values: list[float]) -> np.ndarray:
    values_np = np.asarray(values, dtype=float)
    order = np.argsort(values_np)
    adjusted = np.empty_like(values_np)
    running = 0.0
    for rank, index in enumerate(order):
        running = max(running, (len(values_np) - rank) * values_np[index])
        adjusted[index] = min(1.0, running)
    return adjusted


def bootstrap_delta(delta: np.ndarray, seed: int, draws: int = 20_000) -> tuple[float, float]:
    rng = np.random.default_rng(seed)
    means = rng.choice(delta, size=(draws, len(delta)), replace=True).mean(axis=1)
    return tuple(float(x) for x in np.quantile(means, [0.025, 0.975]))


def sign_flip_p(delta: np.ndarray, seed: int, draws: int = 100_000) -> float:
    rng = np.random.default_rng(seed)
    observed = abs(delta.mean())
    chunk = 5_000
    exceed = 0
    completed = 0
    while completed < draws:
        take = min(chunk, draws - completed)
        signs = rng.choice(np.array([-1.0, 1.0]), size=(take, len(delta)))
        permuted = np.abs((signs * delta).mean(axis=1))
        exceed += int((permuted >= observed).sum())
        completed += take
    return (exceed + 1) / (draws + 1)


def main() -> None:
    RESULTS.mkdir(parents=True, exist_ok=True)
    FIGURES.mkdir(parents=True, exist_ok=True)
    patient = pd.read_csv(SOURCE / "patient_seed_averaged_metrics.csv")

    slice_frames = []
    for variant in VARIANTS:
        for seed in SEEDS:
            for condition in CONDITIONS:
                frame = pd.read_csv(
                    SOURCE / f"{variant}_seed{seed}" / f"test_{condition}_slices.csv"
                )
                frame["variant"] = variant
                frame["seed"] = seed
                frame["condition"] = condition
                slice_frames.append(frame)
    slices = pd.concat(slice_frames, ignore_index=True)
    slice_avg = slices.groupby(
        ["variant", "condition", "pid", "source"], as_index=False
    ).dice.mean()

    rows = []
    for level, frame, unit in [
        ("patient", patient.rename(columns={"corruption": "condition"}), "pid"),
        ("slice", slice_avg, "source"),
    ]:
        for condition in CONDITIONS:
            base = frame[
                (frame.variant == "plain") & (frame.condition == condition)
            ].set_index(unit).dice
            for variant in ["sigmoid", "integrity"]:
                candidate = frame[
                    (frame.variant == variant) & (frame.condition == condition)
                ].set_index(unit).dice
                joined = pd.concat([base.rename("plain"), candidate.rename("candidate")], axis=1).dropna()
                delta = (joined.candidate - joined.plain).to_numpy()
                lo, hi = bootstrap_delta(delta, 9100 + len(rows))
                _, p_wilcoxon = wilcoxon(delta, alternative="two-sided", zero_method="wilcox")
                rows.append(
                    {
                        "analysis_unit": level,
                        "condition": condition,
                        "comparison": f"{variant} - plain",
                        "units": len(delta),
                        "mean_delta_dice": delta.mean(),
                        "median_delta_dice": np.median(delta),
                        "ci_low": lo,
                        "ci_high": hi,
                        "wilcoxon_p_raw": p_wilcoxon,
                        "sign_flip_p_raw": sign_flip_p(delta, 12000 + len(rows)),
                    }
                )
    table = pd.DataFrame(rows)
    for level in ["patient", "slice"]:
        indices = table.index[table.analysis_unit == level]
        table.loc[indices, "wilcoxon_p_holm"] = holm(
            table.loc[indices, "wilcoxon_p_raw"].tolist()
        )
        table.loc[indices, "sign_flip_p_holm"] = holm(
            table.loc[indices, "sign_flip_p_raw"].tolist()
        )
    table.to_csv(RESULTS / "case_study_analysis_unit_sensitivity.csv", index=False)

    plot = table[table.comparison == "integrity - plain"].copy()
    x = np.arange(len(CONDITIONS))
    fig, axes = plt.subplots(1, 2, figsize=(8.7, 3.3), sharey=True)
    for ax, level in zip(axes, ["patient", "slice"]):
        part = plot.set_index(["analysis_unit", "condition"]).loc[level].loc[CONDITIONS]
        values = part.mean_delta_dice.to_numpy()
        errors = np.vstack([values - part.ci_low.to_numpy(), part.ci_high.to_numpy() - values])
        ax.errorbar(x, values, yerr=errors, fmt="o", capsize=4, color="#255f85")
        ax.axhline(0, color="black", linewidth=.9)
        ax.set_xticks(x, [c.capitalize() for c in CONDITIONS])
        ax.set_title(f"{level.capitalize()} as analysis unit (n={int(part.units.iloc[0])})")
        ax.grid(axis="y", alpha=.25)
        for index, p_value in enumerate(part.wilcoxon_p_raw):
            ax.text(index, values[index] + errors[1, index] + .002, f"p={p_value:.3f}", ha="center", fontsize=8)
    axes[0].set_ylabel("Mean Dice difference: integrity - plain")
    fig.suptitle("Correlated slices can change inferential conclusions")
    fig.tight_layout()
    fig.savefig(FIGURES / "analysis_unit_sensitivity.pdf", bbox_inches="tight")
    fig.savefig(FIGURES / "analysis_unit_sensitivity.png", dpi=240, bbox_inches="tight")
    plt.close(fig)
    print(table.to_string(index=False))


if __name__ == "__main__":
    main()
