from __future__ import annotations

"""Cross-framework parity check for GateCheck's numerical contracts."""

import argparse
import json
from pathlib import Path

import jax
import jax.numpy as jnp
import numpy as np
import pandas as pd
import torch


EPS = 1e-12
THRESHOLDS = {
    "constant_std": 1e-6,
    "input_response": 1e-6,
    "forward_effect": 1e-6,
    "parameter_gradient": 1e-10,
    "batch_coupling": 1e-5,
}
CASES = {
    "valid_sigmoid": False,
    "singleton_softmax": True,
    "ignored_forward": True,
    "batch_softmax": True,
    "positive_saturation": True,
}


def _np_relative(a: np.ndarray, b: np.ndarray) -> float:
    return float(np.linalg.norm(a - b) / (np.linalg.norm(b) + EPS))


def _torch_attention(case: str, x: torch.Tensor, weight: torch.Tensor, bias: torch.Tensor) -> torch.Tensor:
    logits = x @ weight + bias
    if case == "singleton_softmax":
        return torch.softmax(logits[..., :1], dim=-1)
    if case == "batch_softmax":
        return torch.softmax(logits, dim=0) * logits.shape[0]
    if case == "positive_saturation":
        return torch.sigmoid(torch.zeros_like(logits) + 100.0)
    return torch.sigmoid(logits)


def run_torch(case: str, seed: int) -> dict[str, object]:
    generator = torch.Generator().manual_seed(seed)
    x = torch.randn((4, 7, 8), generator=generator, requires_grad=True)
    weight = torch.randn((8, 8), generator=generator, requires_grad=True) / 4.0
    bias = torch.randn((8,), generator=generator, requires_grad=True) / 4.0
    weight.retain_grad()
    bias.retain_grad()
    attention = _torch_attention(case, x, weight, bias)
    output = x if case == "ignored_forward" else x * attention
    x_response = torch.flip(x.detach(), dims=(1,)) * 0.7 + 0.19
    response = _torch_attention(case, x_response, weight, bias)
    x_changed = x.detach().clone()
    x_changed[0] = x_changed[0] * 2.3 + 1.7
    independent_attention = _torch_attention(case, x_changed, weight, bias)
    independent_output = x_changed if case == "ignored_forward" else x_changed * independent_attention
    output.square().mean().backward()
    gradient_l1 = float(sum(g.abs().sum() for g in (weight.grad, bias.grad) if g is not None))
    return _metrics(
        case,
        seed,
        "PyTorch",
        attention.detach().numpy(),
        output.detach().numpy(),
        x.detach().numpy(),
        response.detach().numpy(),
        independent_attention.detach().numpy(),
        independent_output.detach().numpy(),
        gradient_l1,
    )


def _jax_attention(case: str, x: jax.Array, weight: jax.Array, bias: jax.Array) -> jax.Array:
    logits = x @ weight + bias
    if case == "singleton_softmax":
        return jax.nn.softmax(logits[..., :1], axis=-1)
    if case == "batch_softmax":
        return jax.nn.softmax(logits, axis=0) * logits.shape[0]
    if case == "positive_saturation":
        return jax.nn.sigmoid(jnp.zeros_like(logits) + 100.0)
    return jax.nn.sigmoid(logits)


def run_jax(case: str, seed: int) -> dict[str, object]:
    rng = np.random.default_rng(seed)
    x = jnp.asarray(rng.standard_normal((4, 7, 8)), dtype=jnp.float32)
    weight = jnp.asarray(rng.standard_normal((8, 8)) / 4.0, dtype=jnp.float32)
    bias = jnp.asarray(rng.standard_normal(8) / 4.0, dtype=jnp.float32)

    def loss(w: jax.Array, b: jax.Array) -> jax.Array:
        attention_i = _jax_attention(case, x, w, b)
        output_i = x if case == "ignored_forward" else x * attention_i
        return jnp.mean(output_i**2)

    grad_w, grad_b = jax.grad(loss, argnums=(0, 1))(weight, bias)
    attention = _jax_attention(case, x, weight, bias)
    output = x if case == "ignored_forward" else x * attention
    x_response = jnp.flip(x, axis=1) * 0.7 + 0.19
    response = _jax_attention(case, x_response, weight, bias)
    x_changed = x.at[0].set(x[0] * 2.3 + 1.7)
    independent_attention = _jax_attention(case, x_changed, weight, bias)
    independent_output = x_changed if case == "ignored_forward" else x_changed * independent_attention
    gradient_l1 = float(jnp.abs(grad_w).sum() + jnp.abs(grad_b).sum())
    return _metrics(
        case,
        seed,
        "JAX",
        np.asarray(attention),
        np.asarray(output),
        np.asarray(x),
        np.asarray(response),
        np.asarray(independent_attention),
        np.asarray(independent_output),
        gradient_l1,
    )


def _metrics(
    case: str,
    seed: int,
    framework: str,
    attention: np.ndarray,
    output: np.ndarray,
    x: np.ndarray,
    response: np.ndarray,
    independent_attention: np.ndarray,
    independent_output: np.ndarray,
    gradient_l1: float,
) -> dict[str, object]:
    finite = bool(np.isfinite(attention).all() and np.isfinite(output).all())
    attention_std = float(np.std(attention)) if finite else float("inf")
    input_response = _np_relative(response, attention) if finite else float("inf")
    forward_effect = _np_relative(output, x) if finite else float("inf")
    batch_coupling = max(
        _np_relative(independent_attention[1:], attention[1:]),
        _np_relative(independent_output[1:], output[1:]),
    ) if finite else float("inf")
    flags = {
        "non_finite": not finite,
        "constant_map": finite and attention_std < THRESHOLDS["constant_std"],
        "input_insensitive": finite and input_response < THRESHOLDS["input_response"],
        "identity_forward": finite and forward_effect < THRESHOLDS["forward_effect"],
        "gradient_isolated": gradient_l1 < THRESHOLDS["parameter_gradient"],
        "batch_coupled": finite and batch_coupling > THRESHOLDS["batch_coupling"],
    }
    detected = any(flags.values())
    return {
        "framework": framework,
        "framework_version": torch.__version__ if framework == "PyTorch" else jax.__version__,
        "case_id": case,
        "expected_fault": CASES[case],
        "seed": seed,
        "attention_std": attention_std,
        "input_response": input_response,
        "forward_effect": forward_effect,
        "parameter_gradient_l1": gradient_l1,
        "batch_coupling": batch_coupling,
        **flags,
        "detected_fault": detected,
        "correct": bool(detected == CASES[case]),
    }


def run(output: Path) -> dict[str, object]:
    output.mkdir(parents=True, exist_ok=True)
    rows = [runner(case, seed) for case in CASES for seed in (17, 43, 101, 2027, 4099) for runner in (run_torch, run_jax)]
    frame = pd.DataFrame(rows)
    cases = frame.groupby(["framework", "framework_version", "case_id", "expected_fault"], as_index=False).agg(
        runs=("correct", "size"), detection_rate=("detected_fault", "mean"), correctness_rate=("correct", "mean")
    )
    parity = frame.pivot(index=["case_id", "seed"], columns="framework", values="detected_fault").reset_index()
    summary = {
        "benchmark": "GateCheck-cross-framework-v1",
        "frameworks": {"PyTorch": torch.__version__, "JAX": jax.__version__},
        "case_definitions": len(CASES),
        "mutant_definitions": int(sum(CASES.values())),
        "executions": int(len(frame)),
        "all_decisions_correct": bool(frame.correct.all()),
        "decision_parity": bool((parity.PyTorch == parity.JAX).all()),
    }
    frame.to_csv(output / "cross_framework_executions.csv", index=False)
    cases.to_csv(output / "cross_framework_cases.csv", index=False)
    parity.to_csv(output / "cross_framework_parity.csv", index=False)
    (output / "cross_framework_summary.json").write_text(json.dumps(summary, indent=2), encoding="utf-8")
    return summary


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", type=Path, default=Path("a_star_research/results"))
    args = parser.parse_args()
    print(json.dumps(run(args.output), indent=2))


if __name__ == "__main__":
    main()
