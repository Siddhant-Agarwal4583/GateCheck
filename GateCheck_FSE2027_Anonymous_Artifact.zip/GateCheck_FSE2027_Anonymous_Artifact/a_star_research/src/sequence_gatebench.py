from __future__ import annotations

"""GateBench-v2 extension for sequence and recurrent-style multiplicative gates."""

import argparse
import json
import math
import time
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Callable, Iterable

import numpy as np
import pandas as pd
import torch
from scipy.stats import beta
from torch import Tensor, nn


EPS = 1e-12


class SequenceGateBase(nn.Module):
    def attention_map(self, x: Tensor) -> Tensor:
        raise NotImplementedError

    def forward(self, x: Tensor) -> Tensor:
        return x * self.attention_map(x)


class TokenSigmoidGate(SequenceGateBase):
    def __init__(self, features: int):
        super().__init__()
        self.score = nn.Linear(features, 1)

    def attention_map(self, x: Tensor) -> Tensor:
        return torch.sigmoid(self.score(x))


class FeatureSigmoidGate(SequenceGateBase):
    def __init__(self, features: int):
        super().__init__()
        self.score = nn.Linear(features, features)

    def attention_map(self, x: Tensor) -> Tensor:
        return torch.sigmoid(self.score(x))


class FeatureSoftmaxGate(FeatureSigmoidGate):
    def attention_map(self, x: Tensor) -> Tensor:
        logits = self.score(x)
        return torch.softmax(logits, dim=-1) * logits.shape[-1]


class ResidualTokenGate(TokenSigmoidGate):
    def __init__(self, features: int):
        super().__init__(features)
        self.mix_logit = nn.Parameter(torch.tensor(-0.5))

    def forward(self, x: Tensor) -> Tensor:
        mix = 0.5 * torch.sigmoid(self.mix_logit)
        return (1.0 - mix) * x + mix * x * self.attention_map(x)


class RecurrentUpdateGate(FeatureSigmoidGate):
    def __init__(self, features: int):
        super().__init__(features)
        self.candidate = nn.Linear(features, features)

    def forward(self, x: Tensor) -> Tensor:
        update = self.attention_map(x)
        candidate = torch.tanh(self.candidate(x))
        return (1.0 - update) * x + update * candidate


class SingletonSoftmaxGate(TokenSigmoidGate):
    def attention_map(self, x: Tensor) -> Tensor:
        return torch.softmax(self.score(x), dim=-1)


class DetachedGate(FeatureSigmoidGate):
    def attention_map(self, x: Tensor) -> Tensor:
        return super().attention_map(x).detach()


class IgnoredGate(FeatureSigmoidGate):
    def forward(self, x: Tensor) -> Tensor:
        _ = self.attention_map(x)
        return x


class ZeroMixGate(FeatureSigmoidGate):
    def forward(self, x: Tensor) -> Tensor:
        return x + 0.0 * x * self.attention_map(x)


class BatchSoftmaxGate(FeatureSigmoidGate):
    def attention_map(self, x: Tensor) -> Tensor:
        logits = self.score(x)
        return torch.softmax(logits, dim=0) * logits.shape[0]


class FirstSampleBroadcastGate(FeatureSigmoidGate):
    def attention_map(self, x: Tensor) -> Tensor:
        first = super().attention_map(x[:1])
        return first.expand(x.shape[0], -1, -1)


class SaturatedGate(FeatureSigmoidGate):
    def __init__(self, features: int, sign: float):
        super().__init__(features)
        nn.init.zeros_(self.score.weight)
        nn.init.constant_(self.score.bias, 100.0 * sign)


class NonFiniteGate(FeatureSigmoidGate):
    def attention_map(self, x: Tensor) -> Tensor:
        return super().attention_map(x) / torch.zeros((), dtype=x.dtype, device=x.device)


class IncompatibleShapeGate(FeatureSigmoidGate):
    def attention_map(self, x: Tensor) -> Tensor:
        return super().attention_map(x)[..., :-1]


@dataclass(frozen=True)
class SequenceCase:
    case_id: str
    family: str
    mutation: str
    expected_fault: bool
    features: int
    factory: Callable[[], nn.Module]


@dataclass(frozen=True)
class Thresholds:
    constant_std: float = 1e-6
    input_response: float = 1e-6
    forward_effect: float = 1e-6
    parameter_gradient: float = 1e-10
    batch_coupling: float = 1e-5


def _relative_l2(a: Tensor, b: Tensor) -> float:
    return float(torch.linalg.vector_norm(a - b) / (torch.linalg.vector_norm(b) + EPS))


def _gradient_l1(module: nn.Module) -> float:
    return float(
        sum(
            parameter.grad.detach().abs().sum()
            for parameter in module.parameters()
            if parameter.grad is not None
        )
    )


def _parameter_count(module: nn.Module) -> int:
    return sum(parameter.numel() for parameter in module.parameters() if parameter.requires_grad)


def run_probe(
    case: SequenceCase,
    *,
    seed: int,
    length: int,
    batch: int,
    distribution: str,
    thresholds: Thresholds,
) -> dict[str, object]:
    torch.manual_seed(seed)
    started = time.perf_counter()
    module = case.factory().to(dtype=torch.float32).train()
    shape = (batch, length, case.features)
    if distribution == "gaussian":
        values = torch.randn(shape)
    elif distribution == "uniform":
        values = 4.0 * torch.rand(shape) - 2.0
    elif distribution == "relu_sparse":
        values = torch.relu(torch.randn(shape))
    elif distribution == "positive_skew":
        values = torch.exp(0.7 * torch.randn(shape)).clamp(max=10.0)
    else:
        raise ValueError(distribution)
    x = values.requires_grad_(True)
    x_independent = x.detach().clone()
    x_independent[0] = x_independent[0] * 2.3 + 1.7
    x_response = torch.flip(x.detach(), dims=(1,)) * 0.7 + 0.19
    row: dict[str, object] = {
        "case_id": case.case_id,
        "family": case.family,
        "mutation": case.mutation,
        "expected_fault": case.expected_fault,
        "features": case.features,
        "seed": seed,
        "length": length,
        "batch": batch,
        "distribution": distribution,
        "runtime_error": False,
    }
    try:
        attention = module.attention_map(x)
        output = module(x)
        with torch.no_grad():
            attention_response = module.attention_map(x_response)
            output_independent = module(x_independent)
            attention_independent = module.attention_map(x_independent)
        if output.shape != x.shape:
            raise RuntimeError(f"output shape {tuple(output.shape)} != input shape {tuple(x.shape)}")
        if attention.shape[0] != x.shape[0]:
            raise RuntimeError("attention batch dimension does not match input")
        finite = bool(torch.isfinite(attention).all() and torch.isfinite(output).all())
        attention_std = float(attention.detach().std(unbiased=False)) if finite else math.inf
        input_response = _relative_l2(attention_response, attention.detach()) if finite else math.inf
        forward_effect = _relative_l2(output.detach(), x.detach()) if finite else math.inf
        batch_coupling = max(
            _relative_l2(output_independent[1:], output.detach()[1:]),
            _relative_l2(attention_independent[1:], attention.detach()[1:]),
        ) if finite else math.inf
        loss = output.square().mean()
        if loss.requires_grad:
            loss.backward()
        gradient_l1 = _gradient_l1(module)
        trainable = _parameter_count(module)
        flags = {
            "non_finite": not finite,
            "constant_map": finite and attention_std < thresholds.constant_std,
            "input_insensitive": finite and input_response < thresholds.input_response,
            "identity_forward": finite and forward_effect < thresholds.forward_effect,
            "gradient_isolated": trainable > 0 and gradient_l1 < thresholds.parameter_gradient,
            "batch_coupled": finite and batch_coupling > thresholds.batch_coupling,
        }
        detected = any(flags.values())
        row.update(
            finite=finite,
            attention_std=attention_std,
            input_response=input_response,
            forward_effect=forward_effect,
            parameter_gradient_l1=gradient_l1,
            trainable_parameters=trainable,
            batch_coupling=batch_coupling,
            **flags,
            detected_fault=detected,
            correct=bool(detected == case.expected_fault),
        )
    except Exception as exc:
        row.update(
            runtime_error=True,
            error_type=type(exc).__name__,
            error_message=str(exc),
            finite=False,
            attention_std=np.nan,
            input_response=np.nan,
            forward_effect=np.nan,
            parameter_gradient_l1=np.nan,
            trainable_parameters=_parameter_count(module),
            batch_coupling=np.nan,
            non_finite=False,
            constant_map=False,
            input_insensitive=False,
            identity_forward=False,
            gradient_isolated=False,
            batch_coupled=False,
            detected_fault=True,
            correct=bool(case.expected_fault),
        )
    row["runtime_ms"] = 1000.0 * (time.perf_counter() - started)
    return row


def build_cases(features: Iterable[int] = (4, 8, 16)) -> list[SequenceCase]:
    controls: dict[str, Callable[[int], nn.Module]] = {
        "token_sigmoid": TokenSigmoidGate,
        "feature_sigmoid": FeatureSigmoidGate,
        "feature_softmax": FeatureSoftmaxGate,
        "residual_token": ResidualTokenGate,
        "recurrent_update": RecurrentUpdateGate,
    }
    mutants: dict[str, Callable[[int], nn.Module]] = {
        "singleton_feature_softmax": SingletonSoftmaxGate,
        "detached_sequence_gate": DetachedGate,
        "ignored_sequence_gate": IgnoredGate,
        "zero_sequence_mix": ZeroMixGate,
        "sequence_batch_softmax": BatchSoftmaxGate,
        "sequence_first_sample_broadcast": FirstSampleBroadcastGate,
        "sequence_positive_saturation": lambda d: SaturatedGate(d, +1.0),
        "sequence_negative_saturation": lambda d: SaturatedGate(d, -1.0),
        "sequence_nonfinite": NonFiniteGate,
        "sequence_incompatible_shape": IncompatibleShapeGate,
    }
    cases: list[SequenceCase] = []
    for features_i in features:
        for name, factory in controls.items():
            cases.append(SequenceCase(f"control.{name}.d{features_i}", name, "none", False, features_i, lambda f=factory, d=features_i: f(d)))
        for name, factory in mutants.items():
            cases.append(SequenceCase(f"mutant.{name}.d{features_i}", "sequence_gate", name, True, features_i, lambda f=factory, d=features_i: f(d)))
    return cases


def _exact(successes: int, trials: int, alpha: float = 0.05) -> list[float]:
    lo = 0.0 if successes == 0 else float(beta.ppf(alpha / 2, successes, trials - successes + 1))
    hi = 1.0 if successes == trials else float(beta.ppf(1 - alpha / 2, successes + 1, trials - successes))
    return [lo, hi]


def summarize(frame: pd.DataFrame, thresholds: Thresholds) -> tuple[dict[str, object], pd.DataFrame]:
    cases = frame.groupby(["case_id", "family", "mutation", "expected_fault"], as_index=False).agg(
        runs=("correct", "size"),
        detection_rate=("detected_fault", "mean"),
        correctness_rate=("correct", "mean"),
        median_runtime_ms=("runtime_ms", "median"),
    )
    cases["prediction"] = cases.detection_rate >= 0.5
    tp = int((cases.expected_fault & cases.prediction).sum())
    fn = int((cases.expected_fault & ~cases.prediction).sum())
    tn = int((~cases.expected_fault & ~cases.prediction).sum())
    fp = int((~cases.expected_fault & cases.prediction).sum())
    summary = {
        "benchmark": "GateBench-v2-sequence",
        "thresholds": asdict(thresholds),
        "case_count": int(len(cases)),
        "control_cases": int((~cases.expected_fault).sum()),
        "mutant_cases": int(cases.expected_fault.sum()),
        "execution_count": int(len(frame)),
        "confusion_matrix": {"tp": tp, "fp": fp, "fn": fn, "tn": tn},
        "recall": tp / (tp + fn),
        "recall_clopper_pearson_95": _exact(tp, tp + fn),
        "specificity": tn / (tn + fp),
        "specificity_clopper_pearson_95": _exact(tn, tn + fp),
        "all_cases_correct": bool((cases.prediction == cases.expected_fault).all()),
        "median_execution_ms": float(frame.runtime_ms.median()),
        "p95_execution_ms": float(frame.runtime_ms.quantile(0.95)),
        "torch_version": torch.__version__,
    }
    return summary, cases


def run(output: Path) -> dict[str, object]:
    output.mkdir(parents=True, exist_ok=True)
    thresholds = Thresholds()
    rows = [
        run_probe(case, seed=seed, length=length, batch=batch, distribution=distribution, thresholds=thresholds)
        for case in build_cases()
        for seed in (17, 43, 101, 2027, 4099)
        for length in (3, 7, 13)
        for batch in (2, 4, 7)
        for distribution in ("gaussian", "uniform", "relu_sparse", "positive_skew")
    ]
    frame = pd.DataFrame(rows)
    summary, cases = summarize(frame, thresholds)
    frame.to_csv(output / "sequence_gatebench_executions.csv", index=False)
    cases.to_csv(output / "sequence_gatebench_cases.csv", index=False)
    (output / "sequence_gatebench_summary.json").write_text(json.dumps(summary, indent=2), encoding="utf-8")
    return summary


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", type=Path, default=Path("a_star_research/results"))
    args = parser.parse_args()
    print(json.dumps(run(args.output), indent=2))


if __name__ == "__main__":
    main()
