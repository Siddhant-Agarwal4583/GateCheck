from __future__ import annotations

import argparse
import json
import math
import time
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Callable, Iterable

import numpy as np
import pandas as pd
import torch
from scipy.stats import beta
from torch import Tensor, nn


EPS = 1e-12


class GateBase(nn.Module):
    """Interface for feature gates evaluated by GateCheck."""

    def attention_map(self, x: Tensor) -> Tensor:
        raise NotImplementedError

    def forward(self, x: Tensor) -> Tensor:
        return x * self.attention_map(x)


class SigmoidChannelGate(GateBase):
    def __init__(self, channels: int):
        super().__init__()
        hidden = max(2, channels // 2)
        self.net = nn.Sequential(
            nn.Conv2d(channels, hidden, 1, bias=False),
            nn.SiLU(),
            nn.Conv2d(hidden, channels, 1),
        )

    def attention_map(self, x: Tensor) -> Tensor:
        return torch.sigmoid(self.net(x.mean(dim=(-2, -1), keepdim=True)))


class SpatialSigmoidGate(GateBase):
    def __init__(self, channels: int):
        super().__init__()
        del channels
        self.score = nn.Conv2d(2, 1, 5, padding=2)

    def attention_map(self, x: Tensor) -> Tensor:
        pooled = torch.cat(
            [x.mean(dim=1, keepdim=True), x.amax(dim=1, keepdim=True)], dim=1
        )
        return torch.sigmoid(self.score(pooled))


class ChannelSoftmaxGate(GateBase):
    def __init__(self, channels: int):
        super().__init__()
        self.score = nn.Conv2d(channels, channels, 1)

    def attention_map(self, x: Tensor) -> Tensor:
        logits = self.score(x.mean(dim=(-2, -1), keepdim=True))
        # Rescale to unit mean so the valid control is not forced to attenuate.
        return torch.softmax(logits, dim=1) * logits.shape[1]


class SpatialSoftmaxGate(GateBase):
    def __init__(self, channels: int):
        super().__init__()
        self.score = nn.Conv2d(channels, 1, 1)

    def attention_map(self, x: Tensor) -> Tensor:
        logits = self.score(x)
        flat = logits.flatten(2)
        return (torch.softmax(flat, dim=-1) * flat.shape[-1]).view_as(logits)


class CBAMLikeGate(GateBase):
    def __init__(self, channels: int):
        super().__init__()
        self.channel = SigmoidChannelGate(channels)
        self.spatial = SpatialSigmoidGate(channels)

    def attention_map(self, x: Tensor) -> Tensor:
        channel = self.channel.attention_map(x)
        return channel * self.spatial.attention_map(x * channel)


class ResidualSigmoidGate(SigmoidChannelGate):
    def __init__(self, channels: int):
        super().__init__(channels)
        self.mix_logit = nn.Parameter(torch.tensor(-0.5))

    def forward(self, x: Tensor) -> Tensor:
        gate = self.attention_map(x)
        mix = 0.5 * torch.sigmoid(self.mix_logit)
        return (1.0 - mix) * x + mix * x * gate


class SingletonChannelSoftmax(GateBase):
    def __init__(self, channels: int):
        super().__init__()
        self.score = nn.Conv2d(channels, 1, 1)

    def attention_map(self, x: Tensor) -> Tensor:
        logits = self.score(x.mean(dim=(-2, -1), keepdim=True))
        return torch.softmax(logits, dim=1)


class SingletonSpatialSoftmax(GateBase):
    def __init__(self, channels: int):
        super().__init__()
        self.score = nn.Conv2d(channels, 1, 1)

    def attention_map(self, x: Tensor) -> Tensor:
        logits = self.score(x).mean(dim=(-2, -1), keepdim=True)
        return torch.softmax(logits.flatten(2), dim=-1).view_as(logits)


class DetachedSigmoidGate(SigmoidChannelGate):
    def attention_map(self, x: Tensor) -> Tensor:
        return super().attention_map(x).detach()


class IgnoredGate(SigmoidChannelGate):
    def forward(self, x: Tensor) -> Tensor:
        _ = self.attention_map(x)
        return x


class ZeroMixGate(SigmoidChannelGate):
    def forward(self, x: Tensor) -> Tensor:
        return x + 0.0 * x * self.attention_map(x)


class BatchSoftmaxGate(GateBase):
    def __init__(self, channels: int):
        super().__init__()
        self.score = nn.Conv2d(channels, channels, 1)

    def attention_map(self, x: Tensor) -> Tensor:
        logits = self.score(x.mean(dim=(-2, -1), keepdim=True))
        # A plausible axis error: samples compete with one another.
        return torch.softmax(logits, dim=0) * logits.shape[0]


class FirstSampleBroadcastGate(SigmoidChannelGate):
    def attention_map(self, x: Tensor) -> Tensor:
        first = super().attention_map(x[:1])
        return first.expand(x.shape[0], -1, -1, -1)


class SaturatedSigmoidGate(GateBase):
    def __init__(self, channels: int, sign: float):
        super().__init__()
        self.score = nn.Conv2d(channels, channels, 1)
        nn.init.zeros_(self.score.weight)
        nn.init.constant_(self.score.bias, 100.0 * sign)

    def attention_map(self, x: Tensor) -> Tensor:
        return torch.sigmoid(self.score(x.mean(dim=(-2, -1), keepdim=True)))


class NonFiniteGate(SigmoidChannelGate):
    def attention_map(self, x: Tensor) -> Tensor:
        valid = super().attention_map(x)
        return valid / torch.zeros((), dtype=x.dtype, device=x.device)


class RuntimeShapeGate(SigmoidChannelGate):
    def attention_map(self, x: Tensor) -> Tensor:
        valid = super().attention_map(x)
        return valid[:, :-1]


@dataclass(frozen=True)
class Case:
    case_id: str
    family: str
    mutation: str
    expected_fault: bool
    channels: int
    factory: Callable[[], nn.Module]


@dataclass(frozen=True)
class Thresholds:
    constant_std: float = 1e-6
    input_response: float = 1e-6
    forward_effect: float = 1e-6
    parameter_gradient: float = 1e-10
    batch_coupling: float = 1e-5


def _relative_l2(a: Tensor, b: Tensor) -> float:
    return float(torch.linalg.vector_norm(a - b) / (torch.linalg.vector_norm(b) + EPS))


def _gradient_l1(module: nn.Module) -> float:
    return float(
        sum(
            parameter.grad.detach().abs().sum()
            for parameter in module.parameters()
            if parameter.grad is not None
        )
    )


def _trainable_parameters(module: nn.Module) -> int:
    return sum(parameter.numel() for parameter in module.parameters() if parameter.requires_grad)


def run_probe(
    case: Case,
    *,
    seed: int,
    height: int,
    width: int,
    batch: int = 4,
    distribution: str = "gaussian",
    thresholds: Thresholds,
) -> dict[str, object]:
    torch.manual_seed(seed)
    started = time.perf_counter()
    module = case.factory().to(dtype=torch.float32)
    module.train()
    shape = (batch, case.channels, height, width)
    if distribution == "gaussian":
        values = torch.randn(shape)
    elif distribution == "uniform":
        values = 4.0 * torch.rand(shape) - 2.0
    elif distribution == "relu_sparse":
        values = torch.relu(torch.randn(shape))
    elif distribution == "positive_skew":
        values = torch.exp(0.7 * torch.randn(shape)).clamp(max=10.0)
    else:
        raise ValueError(f"Unknown distribution: {distribution}")
    x = values.requires_grad_(True)
    x_independent = x.detach().clone()
    x_independent[0] = x_independent[0] * 2.3 + 1.7
    x_response = torch.flip(x.detach(), dims=(-1,)) * 0.7 + 0.19

    row: dict[str, object] = {
        "case_id": case.case_id,
        "family": case.family,
        "mutation": case.mutation,
        "expected_fault": case.expected_fault,
        "channels": case.channels,
        "seed": seed,
        "height": height,
        "width": width,
        "batch": batch,
        "distribution": distribution,
        "runtime_error": False,
    }

    try:
        attention = module.attention_map(x)
        output = module(x)
        with torch.no_grad():
            attention_response = module.attention_map(x_response)
            output_independent = module(x_independent)
            attention_independent = module.attention_map(x_independent)

        if output.shape != x.shape:
            raise RuntimeError(f"output shape {tuple(output.shape)} != input shape {tuple(x.shape)}")
        if attention.shape[0] != x.shape[0]:
            raise RuntimeError("attention batch dimension does not match input")

        finite = bool(torch.isfinite(attention).all() and torch.isfinite(output).all())
        attention_std = float(attention.detach().std(unbiased=False)) if finite else math.inf
        input_response = (
            _relative_l2(attention_response.detach(), attention.detach()) if finite else math.inf
        )
        forward_effect = _relative_l2(output.detach(), x.detach()) if finite else math.inf
        coupling_output = _relative_l2(
            output_independent[1:].detach(), output.detach()[1:]
        ) if finite else math.inf
        coupling_attention = _relative_l2(
            attention_independent[1:].detach(), attention.detach()[1:]
        ) if finite else math.inf
        batch_coupling = max(coupling_output, coupling_attention)

        loss = output.square().mean()
        if loss.requires_grad:
            loss.backward()
        gradient_l1 = _gradient_l1(module)
        trainable = _trainable_parameters(module)

        flags = {
            "non_finite": not finite,
            "constant_map": finite and attention_std < thresholds.constant_std,
            "input_insensitive": finite and input_response < thresholds.input_response,
            "identity_forward": finite and forward_effect < thresholds.forward_effect,
            "gradient_isolated": trainable > 0 and gradient_l1 < thresholds.parameter_gradient,
            "batch_coupled": finite and batch_coupling > thresholds.batch_coupling,
        }
        detected = any(flags.values())
        row.update(
            {
                "finite": finite,
                "attention_std": attention_std,
                "input_response": input_response,
                "forward_effect": forward_effect,
                "parameter_gradient_l1": gradient_l1,
                "trainable_parameters": trainable,
                "batch_coupling": batch_coupling,
                **flags,
                "detected_fault": detected,
                "correct": bool(detected == case.expected_fault),
            }
        )
    except Exception as exc:  # benchmark intentionally contains invalid mutants
        row.update(
            {
                "runtime_error": True,
                "error_type": type(exc).__name__,
                "error_message": str(exc),
                "finite": False,
                "attention_std": np.nan,
                "input_response": np.nan,
                "forward_effect": np.nan,
                "parameter_gradient_l1": np.nan,
                "trainable_parameters": _trainable_parameters(module),
                "batch_coupling": np.nan,
                "non_finite": False,
                "constant_map": False,
                "input_insensitive": False,
                "identity_forward": False,
                "gradient_isolated": False,
                "batch_coupled": False,
                "detected_fault": True,
                "correct": bool(case.expected_fault),
            }
        )

    row["runtime_ms"] = 1000.0 * (time.perf_counter() - started)
    return row


def build_cases(channels: Iterable[int] = (4, 8, 16)) -> list[Case]:
    cases: list[Case] = []

    valid_factories: dict[str, Callable[[int], nn.Module]] = {
        "sigmoid_channel": SigmoidChannelGate,
        "sigmoid_spatial": SpatialSigmoidGate,
        "softmax_channel": ChannelSoftmaxGate,
        "softmax_spatial": SpatialSoftmaxGate,
        "cbam_like": CBAMLikeGate,
        "residual_sigmoid": ResidualSigmoidGate,
    }
    mutant_factories: dict[str, Callable[[int], nn.Module]] = {
        "singleton_channel_softmax": SingletonChannelSoftmax,
        "singleton_spatial_softmax": SingletonSpatialSoftmax,
        "detached_attention": DetachedSigmoidGate,
        "ignored_attention": IgnoredGate,
        "zero_residual_mix": ZeroMixGate,
        "batch_axis_softmax": BatchSoftmaxGate,
        "first_sample_broadcast": FirstSampleBroadcastGate,
        "positive_saturation": lambda c: SaturatedSigmoidGate(c, +1.0),
        "negative_saturation": lambda c: SaturatedSigmoidGate(c, -1.0),
        "nonfinite_division": NonFiniteGate,
        "incompatible_shape": RuntimeShapeGate,
    }

    for channels_i in channels:
        for family, factory in valid_factories.items():
            cases.append(
                Case(
                    case_id=f"control.{family}.c{channels_i}",
                    family=family,
                    mutation="none",
                    expected_fault=False,
                    channels=channels_i,
                    factory=lambda f=factory, c=channels_i: f(c),
                )
            )
        for mutation, factory in mutant_factories.items():
            cases.append(
                Case(
                    case_id=f"mutant.{mutation}.c{channels_i}",
                    family="learned_multiplicative_gate",
                    mutation=mutation,
                    expected_fault=True,
                    channels=channels_i,
                    factory=lambda f=factory, c=channels_i: f(c),
                )
            )
    return cases


def summarize(executions: pd.DataFrame, thresholds: Thresholds) -> dict[str, object]:
    cases = executions.groupby(
        ["case_id", "family", "mutation", "expected_fault"], as_index=False
    ).agg(
        runs=("correct", "size"),
        detection_rate=("detected_fault", "mean"),
        correctness_rate=("correct", "mean"),
        median_runtime_ms=("runtime_ms", "median"),
    )
    cases["case_prediction_fault"] = cases.detection_rate >= 0.5
    cases["case_correct"] = cases.case_prediction_fault == cases.expected_fault

    tp = int(((cases.expected_fault) & (cases.case_prediction_fault)).sum())
    fp = int(((~cases.expected_fault) & (cases.case_prediction_fault)).sum())
    fn = int(((cases.expected_fault) & (~cases.case_prediction_fault)).sum())
    tn = int(((~cases.expected_fault) & (~cases.case_prediction_fault)).sum())
    precision = tp / (tp + fp) if tp + fp else 0.0
    recall = tp / (tp + fn) if tp + fn else 0.0
    specificity = tn / (tn + fp) if tn + fp else 0.0
    f1 = 2 * precision * recall / (precision + recall) if precision + recall else 0.0

    def clopper_pearson(successes: int, trials: int, alpha: float = 0.05) -> list[float]:
        """Exact two-sided binomial interval for descriptive case-level rates."""
        lower = 0.0 if successes == 0 else float(beta.ppf(alpha / 2, successes, trials - successes + 1))
        upper = 1.0 if successes == trials else float(beta.ppf(1 - alpha / 2, successes + 1, trials - successes))
        return [lower, upper]

    flag_columns = [
        "runtime_error",
        "non_finite",
        "constant_map",
        "input_insensitive",
        "identity_forward",
        "gradient_isolated",
        "batch_coupled",
    ]
    mutation_detection = (
        executions[executions.expected_fault]
        .groupby("mutation", as_index=False)
        .agg(
            executions=("detected_fault", "size"),
            detection_rate=("detected_fault", "mean"),
            median_runtime_ms=("runtime_ms", "median"),
        )
        .sort_values("mutation")
    )
    flag_rates = (
        executions.groupby("mutation", as_index=False)[flag_columns]
        .mean(numeric_only=True)
        .sort_values("mutation")
    )
    summary = {
        "benchmark": "GateBench-v1",
        "thresholds": asdict(thresholds),
        "case_count": int(len(cases)),
        "control_cases": int((~cases.expected_fault).sum()),
        "mutant_cases": int(cases.expected_fault.sum()),
        "execution_count": int(len(executions)),
        "seeds": sorted(int(x) for x in executions.seed.unique()),
        "batch_sizes": sorted(int(x) for x in executions.batch.unique()),
        "input_distributions": sorted(str(x) for x in executions.distribution.unique()),
        "shapes": sorted(
            {f"{int(r.channels)}x{int(r.height)}x{int(r.width)}" for r in executions.itertuples()}
        ),
        "confusion_matrix": {"tp": tp, "fp": fp, "fn": fn, "tn": tn},
        "precision": precision,
        "recall": recall,
        "recall_clopper_pearson_95": clopper_pearson(tp, tp + fn),
        "specificity": specificity,
        "specificity_clopper_pearson_95": clopper_pearson(tn, tn + fp),
        "f1": f1,
        "all_cases_correct": bool(cases.case_correct.all()),
        "median_execution_ms": float(executions.runtime_ms.median()),
        "p95_execution_ms": float(executions.runtime_ms.quantile(0.95)),
    }
    return {
        "summary": summary,
        "cases": cases,
        "mutation_detection": mutation_detection,
        "flag_rates": flag_rates,
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", type=Path, default=Path("a_star_research/results"))
    args = parser.parse_args()
    args.output.mkdir(parents=True, exist_ok=True)

    thresholds = Thresholds()
    rows: list[dict[str, object]] = []
    shapes = [(8, 8), (9, 11), (16, 12)]
    batches = [2, 4, 7]
    distributions = ["gaussian", "uniform", "relu_sparse", "positive_skew"]
    seeds = [17, 43, 101, 2027, 4099]
    for case in build_cases():
        for seed in seeds:
            for height, width in shapes:
                for batch in batches:
                    for distribution in distributions:
                        rows.append(
                            run_probe(
                                case,
                                seed=seed,
                                height=height,
                                width=width,
                                batch=batch,
                                distribution=distribution,
                                thresholds=thresholds,
                            )
                        )

    executions = pd.DataFrame(rows)
    report = summarize(executions, thresholds)
    executions.to_csv(args.output / "gatebench_executions.csv", index=False)
    report["cases"].to_csv(args.output / "gatebench_cases.csv", index=False)
    report["mutation_detection"].to_csv(
        args.output / "gatebench_mutation_detection.csv", index=False
    )
    report["flag_rates"].to_csv(args.output / "gatebench_flag_rates.csv", index=False)
    (args.output / "gatebench_summary.json").write_text(
        json.dumps(report["summary"], indent=2), encoding="utf-8"
    )
    print(json.dumps(report["summary"], indent=2))


if __name__ == "__main__":
    main()
