from __future__ import annotations

import json
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd


RESULTS = Path("a_star_research/results")
FIGURES = Path("a_star_research/figures")
PROBES = [
    "runtime_error",
    "non_finite",
    "constant_map",
    "input_insensitive",
    "identity_forward",
    "gradient_isolated",
    "batch_coupled",
]
PROBE_LABELS = [
    "Runtime/shape",
    "Finiteness",
    "Non-constancy",
    "Input response",
    "Forward effect",
    "Gradient flow",
    "Batch independence",
]


def case_score(frame: pd.DataFrame, detected: pd.Series) -> dict[str, float]:
    work = frame[["case_id", "expected_fault"]].copy()
    work["detected"] = detected.astype(bool)
    cases = work.groupby(["case_id", "expected_fault"], as_index=False).detected.mean()
    cases["prediction"] = cases.detected >= 0.5
    tp = ((cases.expected_fault) & (cases.prediction)).sum()
    fp = ((~cases.expected_fault) & (cases.prediction)).sum()
    fn = ((cases.expected_fault) & (~cases.prediction)).sum()
    tn = ((~cases.expected_fault) & (~cases.prediction)).sum()
    return {
        "recall": float(tp / (tp + fn)),
        "specificity": float(tn / (tn + fp)),
        "false_positive_rate": float(fp / (fp + tn)),
    }


def main() -> None:
    FIGURES.mkdir(parents=True, exist_ok=True)
    frame = pd.read_csv(RESULTS / "gatebench_executions.csv")

    strategies = {
        "Runtime/shape only": ["runtime_error"],
        "+ finiteness": ["runtime_error", "non_finite"],
        "+ value dynamics": [
            "runtime_error",
            "non_finite",
            "constant_map",
            "input_insensitive",
        ],
        "+ forward/backward": [
            "runtime_error",
            "non_finite",
            "constant_map",
            "input_insensitive",
            "identity_forward",
            "gradient_isolated",
        ],
        "Full GateCheck": PROBES,
    }
    ablations = []
    for name, columns in strategies.items():
        score = case_score(frame, frame[columns].any(axis=1))
        ablations.append({"strategy": name, **score})
    ablations = pd.DataFrame(ablations)
    ablations.to_csv(RESULTS / "probe_strategy_ablation.csv", index=False)

    leave_one_out = []
    for omitted in ["none", *PROBES]:
        columns = PROBES if omitted == "none" else [p for p in PROBES if p != omitted]
        score = case_score(frame, frame[columns].any(axis=1))
        leave_one_out.append({"omitted_probe": omitted, **score})
    pd.DataFrame(leave_one_out).to_csv(
        RESULTS / "leave_one_probe_out.csv", index=False
    )

    mutants = frame[frame.expected_fault]
    heat = mutants.groupby("mutation")[PROBES].mean().sort_index()
    heat.to_csv(RESULTS / "mutation_probe_matrix.csv")

    defaults = {
        "constant_std": 1e-6,
        "input_response": 1e-6,
        "forward_effect": 1e-6,
        "parameter_gradient_l1": 1e-10,
        "batch_coupling": 1e-5,
    }
    sweep_rows = []
    for factor in np.logspace(-4, 4, 17):
        detected = (
            frame.runtime_error
            | (~frame.finite)
            | (frame.attention_std < defaults["constant_std"] * factor)
            | (frame.input_response < defaults["input_response"] * factor)
            | (frame.forward_effect < defaults["forward_effect"] * factor)
            | (
                (frame.trainable_parameters > 0)
                & (frame.parameter_gradient_l1 < defaults["parameter_gradient_l1"] * factor)
            )
            | (frame.batch_coupling > defaults["batch_coupling"] * factor)
        )
        sweep_rows.append({"threshold_factor": factor, **case_score(frame, detected)})
    sweep = pd.DataFrame(sweep_rows)
    sweep.to_csv(RESULTS / "threshold_sensitivity.csv", index=False)

    plt.rcParams.update({"font.size": 9, "axes.titlesize": 10, "axes.labelsize": 9})
    fig, ax = plt.subplots(figsize=(9.0, 4.8))
    image = ax.imshow(heat.to_numpy(), vmin=0, vmax=1, cmap="Blues", aspect="auto")
    ax.set_xticks(np.arange(len(PROBES)), PROBE_LABELS, rotation=35, ha="right")
    ax.set_yticks(np.arange(len(heat)), [x.replace("_", " ") for x in heat.index])
    for i in range(len(heat)):
        for j in range(len(PROBES)):
            value = heat.iloc[i, j]
            if value > 0:
                ax.text(j, i, f"{value:.0%}", ha="center", va="center", color="white" if value > .6 else "black", fontsize=8)
    ax.set_title("GateBench-v1: which property detects each semantic mutation")
    fig.colorbar(image, ax=ax, label="Detection frequency")
    fig.tight_layout()
    fig.savefig(FIGURES / "mutation_probe_matrix.pdf", bbox_inches="tight")
    fig.savefig(FIGURES / "mutation_probe_matrix.png", dpi=240, bbox_inches="tight")
    plt.close(fig)

    fig, axes = plt.subplots(1, 2, figsize=(9.0, 3.4))
    positions = np.arange(len(ablations))
    axes[0].bar(positions, ablations.recall, color="#255f85")
    axes[0].set_xticks(positions, ablations.strategy, rotation=35, ha="right")
    axes[0].set_ylim(0, 1.08)
    axes[0].set_ylabel("Case-level mutant recall")
    axes[0].grid(axis="y", alpha=.25)
    for i, value in enumerate(ablations.recall):
        axes[0].text(i, value + .025, f"{value:.0%}", ha="center", fontsize=8)

    axes[1].semilogx(sweep.threshold_factor, sweep.recall, marker="o", label="Recall")
    axes[1].semilogx(sweep.threshold_factor, sweep.specificity, marker="s", label="Specificity")
    axes[1].axvline(1.0, color="black", linestyle="--", linewidth=1, label="Prespecified")
    axes[1].set_ylim(0, 1.03)
    axes[1].set_xlabel("Joint threshold multiplier")
    axes[1].set_ylabel("Case-level rate")
    axes[1].grid(alpha=.25)
    axes[1].legend(frameon=False, loc="lower left")
    fig.suptitle("Property-suite ablation and threshold stress test")
    fig.tight_layout()
    fig.savefig(FIGURES / "gatebench_ablations.pdf", bbox_inches="tight")
    fig.savefig(FIGURES / "gatebench_ablations.png", dpi=240, bbox_inches="tight")
    plt.close(fig)

    summary = json.loads((RESULTS / "gatebench_summary.json").read_text())
    summary["default_threshold_sweep_recall"] = float(
        sweep.loc[np.isclose(sweep.threshold_factor, 1), "recall"].iloc[0]
    )
    summary["default_threshold_sweep_specificity"] = float(
        sweep.loc[np.isclose(sweep.threshold_factor, 1), "specificity"].iloc[0]
    )
    (RESULTS / "gatebench_summary.json").write_text(json.dumps(summary, indent=2))
    print(ablations.to_string(index=False))
    print("\nThreshold sweep:\n", sweep.to_string(index=False))


if __name__ == "__main__":
    main()
