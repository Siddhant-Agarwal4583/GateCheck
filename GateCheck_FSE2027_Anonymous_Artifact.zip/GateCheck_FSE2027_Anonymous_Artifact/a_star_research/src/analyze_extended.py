from __future__ import annotations

import json
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd


RESULTS = Path("a_star_research/results")
FIGURES = Path("a_star_research/figures")


def load_json(name: str) -> dict[str, object]:
    return json.loads((RESULTS / name).read_text(encoding="utf-8"))


def main() -> None:
    FIGURES.mkdir(parents=True, exist_ok=True)
    spatial = load_json("gatebench_summary.json")
    sequence = load_json("sequence_gatebench_summary.json")
    real = load_json("real_fault_summary.json")
    cross = load_json("cross_framework_summary.json")

    overview = {
        "controlled_case_count": spatial["case_count"] + sequence["case_count"],
        "controlled_mutants": spatial["mutant_cases"] + sequence["mutant_cases"],
        "controlled_controls": spatial["control_cases"] + sequence["control_cases"],
        "controlled_executions": spatial["execution_count"] + sequence["execution_count"],
        "real_fault_pairs": real["fault_pairs"],
        "real_fault_executions": real["executions"],
        "cross_framework_executions": cross["executions"],
        "total_executions": spatial["execution_count"] + sequence["execution_count"] + real["executions"] + cross["executions"],
        "frameworks_executed": sorted(cross["frameworks"]),
        "cross_framework_decision_parity": cross["decision_parity"],
        "public_projects_in_real_fault_pilot": real["projects"],
    }
    (RESULTS / "extended_summary.json").write_text(json.dumps(overview, indent=2), encoding="utf-8")

    labels = ["Spatial\nmutants", "Spatial\ncontrols", "Sequence\nmutants", "Sequence\ncontrols", "Public-patch\nbuggy", "Public-patch\nfixed"]
    values = np.array([spatial["recall"], spatial["specificity"], sequence["recall"], sequence["specificity"], real["buggy_recall"], real["fixed_specificity"]])
    intervals = [spatial["recall_clopper_pearson_95"], spatial["specificity_clopper_pearson_95"], sequence["recall_clopper_pearson_95"], sequence["specificity_clopper_pearson_95"], real["buggy_recall_clopper_pearson_95"], real["fixed_specificity_clopper_pearson_95"]]
    lower = values - np.array([x[0] for x in intervals])
    upper = np.array([x[1] for x in intervals]) - values
    colors = ["#35618f", "#7da3c7", "#2b7a78", "#79b9b4", "#a6504f", "#d49290"]

    fig, ax = plt.subplots(figsize=(8.8, 3.8))
    x = np.arange(len(labels))
    ax.bar(x, values, color=colors, width=0.72)
    ax.errorbar(x, values, yerr=np.vstack([lower, upper]), fmt="none", ecolor="#202020", capsize=4, linewidth=1.2)
    ax.set_xticks(x, labels)
    ax.set_ylim(0, 1.08)
    ax.set_ylabel("Case-level rate")
    ax.set_title("Detection and non-alarm rates with exact 95% binomial intervals")
    ax.grid(axis="y", alpha=0.25)
    for i, value in enumerate(values):
        ax.text(i, 1.015, f"{value:.0%}", ha="center", va="bottom", fontsize=9)
    fig.tight_layout()
    fig.savefig(FIGURES / "extended_evidence_overview.pdf", bbox_inches="tight")
    fig.savefig(FIGURES / "extended_evidence_overview.png", dpi=240, bbox_inches="tight")
    plt.close(fig)

    real_cases = pd.read_csv(RESULTS / "real_fault_case_results.csv")
    pivot = real_cases.pivot(index="fault_id", columns="version", values="flag_rate").reset_index()
    pivot.to_csv(RESULTS / "real_fault_pair_summary.csv", index=False)

    probe_columns = ["runtime_error", "non_finite", "constant_map", "input_insensitive", "identity_forward", "gradient_isolated", "batch_coupled"]
    controlled = pd.concat(
        [
            pd.read_csv(RESULTS / "gatebench_executions.csv")[["case_id", "expected_fault", *probe_columns]],
            pd.read_csv(RESULTS / "sequence_gatebench_executions.csv")[["case_id", "expected_fault", *probe_columns]],
        ],
        ignore_index=True,
    )
    strategies = {
        "Runtime/shape only": ["runtime_error"],
        "+ finiteness": ["runtime_error", "non_finite"],
        "+ value dynamics": ["runtime_error", "non_finite", "constant_map", "input_insensitive"],
        "+ forward/backward": ["runtime_error", "non_finite", "constant_map", "input_insensitive", "identity_forward", "gradient_isolated"],
        "Full GateCheck": probe_columns,
    }
    rows = []
    for strategy, columns in strategies.items():
        decisions = controlled[["case_id", "expected_fault"]].copy()
        decisions["flagged"] = controlled[columns].any(axis=1)
        cases = decisions.groupby(["case_id", "expected_fault"], as_index=False).flagged.mean()
        cases["prediction"] = cases.flagged >= 0.5
        tp = int((cases.expected_fault & cases.prediction).sum())
        fn = int((cases.expected_fault & ~cases.prediction).sum())
        tn = int((~cases.expected_fault & ~cases.prediction).sum())
        fp = int((~cases.expected_fault & cases.prediction).sum())
        rows.append({"strategy": strategy, "mutant_recall": tp / (tp + fn), "control_specificity": tn / (tn + fp), "tp": tp, "fn": fn, "tn": tn, "fp": fp})
    pd.DataFrame(rows).to_csv(RESULTS / "extended_probe_strategy_ablation.csv", index=False)
    print(json.dumps(overview, indent=2))


if __name__ == "__main__":
    main()
