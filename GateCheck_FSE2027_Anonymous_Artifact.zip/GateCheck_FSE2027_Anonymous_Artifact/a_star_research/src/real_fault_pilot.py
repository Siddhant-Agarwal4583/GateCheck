from __future__ import annotations

"""Patch-derived micro-replays of public attention defects.

The replays preserve the semantic difference shown by each public patch while
removing model weights, datasets, and unrelated framework machinery.  They are
therefore not full historical environment reproductions.  Every case records
its immutable commit URL and evaluates both the buggy and fixed behavior with
the same declared contract.
"""

import argparse
import json
import math
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Callable

import pandas as pd
import torch
from scipy.stats import beta
from torch import Tensor
from torch.nn import functional as F


EPS = 1e-12


@dataclass(frozen=True)
class Replay:
    fault_id: str
    project: str
    commit: str
    date: str
    pull_request: str
    defect: str
    contract: str
    probe: Callable[[bool, int], tuple[float, bool]]

    @property
    def commit_url(self) -> str:
        return f"https://github.com/{self.project}/commit/{self.commit}"


def _relative_l2(a: Tensor, b: Tensor) -> float:
    return float(torch.linalg.vector_norm(a - b) / (torch.linalg.vector_norm(b) + EPS))


def _masked_cross_attention(query: Tensor, encoder: Tensor, mask: Tensor | None) -> Tensor:
    scores = torch.matmul(query, encoder.transpose(-1, -2)) / math.sqrt(query.shape[-1])
    if mask is not None:
        scores = scores.masked_fill(mask[:, None, :] == 0, torch.finfo(scores.dtype).min)
    return torch.matmul(F.softmax(scores, dim=-1), encoder)


def probe_discarded_encoder_mask(fixed: bool, seed: int) -> tuple[float, bool]:
    """HF Transformers #47946: protected positions must not affect output."""
    generator = torch.Generator().manual_seed(seed)
    query = torch.randn((2, 3, 8), generator=generator)
    encoder = torch.randn((2, 6, 8), generator=generator)
    mask = torch.ones((2, 6), dtype=torch.int64)
    mask[:, 3:] = 0
    corrupted = encoder.clone()
    corrupted[:, 3:] = 1e6

    effective_mask = mask if fixed else None
    baseline = _masked_cross_attention(query, encoder, effective_mask)
    changed = _masked_cross_attention(query, corrupted, effective_mask)
    metric = _relative_l2(changed, baseline)
    passed = metric <= 1e-7
    return metric, passed


def _scaled_attention(query: Tensor, key: Tensor, value: Tensor, scale: float) -> Tensor:
    weights = F.softmax(torch.matmul(query, key.transpose(-1, -2)) * scale, dim=-1)
    return torch.matmul(weights, value)


def probe_ignored_scaling_configuration(fixed: bool, seed: int) -> tuple[float, bool]:
    """HF Transformers #44397: a declared scaling flag must influence SDPA."""
    generator = torch.Generator().manual_seed(seed)
    query = torch.randn((2, 2, 4, 8), generator=generator)
    key = torch.randn((2, 2, 5, 8), generator=generator)
    value = torch.randn((2, 2, 5, 8), generator=generator)
    default_scale = query.shape[-1] ** -0.5
    layer_index = 2

    if fixed:
        output_unscaled = _scaled_attention(query, key, value, 1.0)
        output_inverse_layer = _scaled_attention(query, key, value, 1.0 / (layer_index + 1))
    else:
        # The affected SDPA path used its default in both configurations.
        output_unscaled = _scaled_attention(query, key, value, default_scale)
        output_inverse_layer = _scaled_attention(query, key, value, default_scale)
    metric = _relative_l2(output_unscaled, output_inverse_layer)
    passed = metric >= 1e-5
    return metric, passed


def _attention_processor(hidden_states: Tensor, *, scale: float = 1.0) -> Tensor:
    # A minimal processor whose documented kwarg has an observable effect.
    return hidden_states * scale + hidden_states.square() * (1.0 - scale)


def probe_dropped_attention_kwargs(fixed: bool, seed: int) -> tuple[float, bool]:
    """HF Diffusers #9517: joint_attention_kwargs must reach the processor."""
    generator = torch.Generator().manual_seed(seed)
    hidden = torch.randn((2, 7, 8), generator=generator)

    def block(scale: float) -> Tensor:
        if fixed:
            return _attention_processor(hidden, scale=scale)
        return _attention_processor(hidden)

    baseline = block(1.0)
    changed = block(0.25)
    metric = _relative_l2(changed, baseline)
    passed = metric >= 1e-5
    return metric, passed


def probe_fp16_softmax_finiteness(fixed: bool, seed: int) -> tuple[float, bool]:
    """HF Transformers #17437: a fully masked fp16 row must stay finite."""
    del seed
    logits = torch.full((2, 4), -100.0, dtype=torch.float16)
    mask = torch.full_like(logits, torch.finfo(torch.float16).min)
    masked = logits + mask  # underflows to -inf in fp16
    if fixed:
        masked = torch.clamp_min(masked, torch.finfo(masked.dtype).min)
        probabilities = F.softmax(masked, dim=-1, dtype=torch.float32).to(torch.float16)
    else:
        probabilities = F.softmax(masked, dim=-1)
    finite_fraction = float(torch.isfinite(probabilities).float().mean())
    passed = finite_fraction == 1.0
    return finite_fraction, passed


class _EmptyCache:
    def get_seq_length(self) -> int:
        return 0


def probe_first_step_conditioning(fixed: bool, seed: int) -> tuple[float, bool]:
    """HF Transformers #48679: an empty cache must not suppress conditioning."""
    generator = torch.Generator().manual_seed(seed)
    conditioning = torch.randn((2, 5, 8), generator=generator)
    cache = _EmptyCache()
    if fixed:
        prepared = conditioning if cache.get_seq_length() == 0 else None
    else:
        prepared = None if cache is not None else conditioning
    retained_fraction = 0.0 if prepared is None else float(prepared.numel() / conditioning.numel())
    passed = retained_fraction == 1.0
    return retained_fraction, passed


def build_replays() -> list[Replay]:
    return [
        Replay(
            "HF-Transformers-47946",
            "huggingface/transformers",
            "e0aeab4c9f7102d18d15b478eec075f9e1658223",
            "2026-08-18",
            "47946",
            "encoder attention mask overwritten and silently discarded",
            "protected-region invariance",
            probe_discarded_encoder_mask,
        ),
        Replay(
            "HF-Transformers-44397",
            "huggingface/transformers",
            "8757098be4d2386d45900b30168855996ca22810",
            "2026-03-05",
            "44397",
            "attention scaling configuration ignored by SDPA/FlashAttention",
            "configuration influence",
            probe_ignored_scaling_configuration,
        ),
        Replay(
            "HF-Diffusers-9517",
            "huggingface/diffusers",
            "acd6d2c42f0fa4fade262e8814279748a544b0ce",
            "2024-10-09",
            "9517",
            "joint attention keyword arguments not forwarded to processor",
            "argument influence",
            probe_dropped_attention_kwargs,
        ),
        Replay(
            "HF-Transformers-17437",
            "huggingface/transformers",
            "d444edb3f63d0ab2e67150a15205f5024b93d7a8",
            "2022-06-29",
            "17437",
            "half-precision masked softmax produced NaNs",
            "finiteness",
            probe_fp16_softmax_finiteness,
        ),
        Replay(
            "HF-Transformers-48679",
            "huggingface/transformers",
            "5bed62964cfec54a806a620eddcf459b29fe4731",
            "2026-09-10",
            "48679",
            "empty pre-created cache caused first-step conditioning to be dropped",
            "first-step conditioning preservation",
            probe_first_step_conditioning,
        ),
    ]


def _exact_interval(successes: int, trials: int, alpha: float = 0.05) -> list[float]:
    lower = 0.0 if successes == 0 else float(beta.ppf(alpha / 2, successes, trials - successes + 1))
    upper = 1.0 if successes == trials else float(beta.ppf(1 - alpha / 2, successes + 1, trials - successes))
    return [lower, upper]


def run(output: Path, seeds: tuple[int, ...] = (17, 43, 101, 2027, 4099)) -> dict[str, object]:
    output.mkdir(parents=True, exist_ok=True)
    rows: list[dict[str, object]] = []
    manifest: list[dict[str, object]] = []
    for replay in build_replays():
        manifest.append(
            {
                "fault_id": replay.fault_id,
                "project": replay.project,
                "commit": replay.commit,
                "date": replay.date,
                "pull_request": replay.pull_request,
                "defect": replay.defect,
                "contract": replay.contract,
                "commit_url": replay.commit_url,
                "replay_scope": "patch-derived semantic micro-replay; not full historical environment",
            }
        )
        for seed in seeds:
            for version, fixed in (("buggy", False), ("fixed", True)):
                metric, contract_passed = replay.probe(fixed, seed)
                rows.append(
                    {
                        "fault_id": replay.fault_id,
                        "project": replay.project,
                        "contract": replay.contract,
                        "version": version,
                        "seed": seed,
                        "metric": metric,
                        "contract_passed": contract_passed,
                        "flagged": not contract_passed,
                    }
                )

    executions = pd.DataFrame(rows)
    case_results = (
        executions.groupby(["fault_id", "project", "contract", "version"], as_index=False)
        .agg(runs=("flagged", "size"), flag_rate=("flagged", "mean"), median_metric=("metric", "median"))
    )
    buggy = case_results[case_results.version == "buggy"]
    fixed = case_results[case_results.version == "fixed"]
    detected = int((buggy.flag_rate >= 0.5).sum())
    false_alarms = int((fixed.flag_rate >= 0.5).sum())
    cases = len(build_replays())
    summary = {
        "benchmark": "RealFaultPilot-v1",
        "scope": "patch-derived semantic micro-replays, not full historical project reproductions",
        "fault_pairs": cases,
        "projects": sorted(executions.project.unique().tolist()),
        "executions": int(len(executions)),
        "seeds": list(seeds),
        "buggy_detected": detected,
        "buggy_recall": detected / cases,
        "buggy_recall_clopper_pearson_95": _exact_interval(detected, cases),
        "fixed_flagged": false_alarms,
        "fixed_specificity": (cases - false_alarms) / cases,
        "fixed_specificity_clopper_pearson_95": _exact_interval(cases - false_alarms, cases),
        "all_buggy_flagged": bool((buggy.flag_rate == 1.0).all()),
        "all_fixed_pass": bool((fixed.flag_rate == 0.0).all()),
        "torch_version": torch.__version__,
    }
    executions.to_csv(output / "real_fault_executions.csv", index=False)
    case_results.to_csv(output / "real_fault_case_results.csv", index=False)
    pd.DataFrame(manifest).to_csv(output / "real_fault_manifest.csv", index=False)
    (output / "real_fault_summary.json").write_text(json.dumps(summary, indent=2), encoding="utf-8")
    return summary


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", type=Path, default=Path("a_star_research/results"))
    args = parser.parse_args()
    print(json.dumps(run(args.output), indent=2))


if __name__ == "__main__":
    main()
