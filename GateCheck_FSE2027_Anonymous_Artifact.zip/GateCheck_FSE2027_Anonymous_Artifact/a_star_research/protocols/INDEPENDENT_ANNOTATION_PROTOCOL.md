# Independent annotation protocol (not yet executed)

This protocol is prepared for the larger study required before GateCheck can support a strong real-fault generalization claim. No annotation results are reported in the current paper.

## Roles

- Two annotators with practical experience in at least one supported deep-learning framework.
- One adjudicator who does not see GateCheck outcomes before resolving disagreements.
- Annotators must not be the benchmark implementation author.

## Blinded material

For each candidate, annotators receive the issue/PR discussion, buggy code, fixed patch, and relevant developer test. They do not receive GateCheck flags or threshold values.

## Labels

1. Developer-confirmed defect: yes/no/unclear.
2. Buggy and fixed code correspond to the public source: yes/no/unclear.
3. Executable environment reproduced: full/semantic-only/no.
4. Contract family: runtime-shape, finiteness, non-degeneracy, input influence, forward effect, gradient connectivity, batch independence, protected-input invariance, declared-option influence, unsupported.
5. Expected relation and axes, in prose.
6. Confidence: high/medium/low.
7. Exclusion reason, if any.

## Analysis

- Freeze inclusion/exclusion before revealing tool outcomes.
- Report raw agreement and Krippendorff's alpha with uncertainty.
- Publish all screened candidates and exclusion reasons.
- Resolve disagreement by adjudication; preserve original labels.
- Evaluate thresholds on projects disjoint from any calibration set.

## Ethics

If annotators are recruited as research participants, obtain the institutionally required ethics determination or approval and informed consent before collecting data. Do not infer or fabricate participant responses.
