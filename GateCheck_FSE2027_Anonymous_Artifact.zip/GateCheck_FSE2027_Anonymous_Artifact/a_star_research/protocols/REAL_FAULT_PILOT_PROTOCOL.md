# RealFaultPilot-v1 protocol

Protocol freeze date: 13 September 2026 (UTC)

## Purpose and claim boundary

This pilot tests whether GateCheck-style contracts expose the semantic difference in a small set of public attention defect patches. It is not a systematic real-fault corpus and does not reproduce full historical project environments. Each replay is a minimal, patch-derived executable pair that preserves the behavior changed by the public commit.

## Discovery queries

The GitHub commit-search API was queried with:

- `fix attention bug repo:huggingface/transformers`
- `fix attention mask repo:huggingface/transformers`
- `fix softmax repo:huggingface/transformers`
- `fix attention bug repo:huggingface/diffusers`
- `fix attention bug repo:huggingface/pytorch-image-models`
- `fix attention bug repo:Project-MONAI/MONAI`

Search results are mutable. The immutable commit hashes used in the pilot are recorded in `results/real_fault_manifest.csv`.

## Inclusion criteria

A candidate was included only when all of the following were true before running the replay:

1. A public commit and patch were available at an immutable hash.
2. The commit or regression test explicitly described the erroneous attention behavior.
3. The semantic change mapped to a declared contract (finiteness, influence, preservation, or invariance).
4. The changed behavior could be represented without proprietary data, model weights, or accelerator-only kernels.
5. The buggy and fixed forms could be executed with identical generated inputs.

The XGLM fp16 softmax patch at commit `9d732fd2dd99cd5c353a6e50c2fc5059d99e1172` was not included because it duplicates the OPT numerical mechanism already represented. Model additions, unrelated bugs, and patches requiring unavailable model weights or accelerator-specific runtimes were not included.

## Outcome rule

The contract and threshold for each pair are encoded in `src/real_fault_pilot.py`. A fault is detected only when every prespecified seed flags the buggy version and none flags the fixed version. Case-level rates, not repeated executions, are used for exact binomial intervals.

## Known limitations

- Convenience sample of five fault pairs from two Hugging Face projects.
- One executed framework (PyTorch) for the public-patch pilot.
- Minimal semantic replays, not historical checkout/container reproductions.
- No independent annotator; the benchmark author selected the contracts.
- No claim about prevalence, representativeness, or performance on unseen faults.

These constraints are mandatory language in any report using this pilot.
