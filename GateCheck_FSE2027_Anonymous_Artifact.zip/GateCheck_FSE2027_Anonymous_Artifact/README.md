# GateCheck anonymous research artifact

This artifact supports the anonymous FSE 2027 submission “GateCheck: Executable Semantic Contracts for Silent Failures in Learned Gates and Attention Components.”

## Evidence included

- 63 controlled semantic-mutant configurations and 33 valid controls.
- 17,280 spatial and sequence stress executions.
- Five public-patch-derived buggy/fixed semantic replays from immutable Transformers and Diffusers commits.
- A 50-execution PyTorch/JAX contract-decision parity check.
- Probe-family ablation, threshold sensitivity, exact case-level intervals, and timing.
- Patient-level reanalysis of the Cheng brain-tumor case study.
- Seven automated tests, frozen protocols, raw rows, aggregate tables, and vector figures.

The public-patch cases are minimal semantic replays, not complete historical checkout reproductions. This boundary is recorded in `protocols/REAL_FAULT_PILOT_PROTOCOL.md` and every manifest row.

## Install and run

Python 3.12 is recommended. From the directory containing `a_star_research`:

```bash
python -m pip install -r a_star_research/requirements.txt
bash a_star_research/run_all.sh
```

The full controlled rerun may take several minutes on a CPU. A fast correctness check is:

```bash
PYTHONPATH=a_star_research/src python -m pytest -q a_star_research/tests
```

Expected test result: `7 passed`.

## Main files

- `src/gatecheck.py`: spatial controlled benchmark and local contracts.
- `src/sequence_gatebench.py`: sequence/recurrent-style extension.
- `src/real_fault_pilot.py`: five public-patch micro-replays.
- `src/cross_framework_check.py`: matched PyTorch/JAX definitions.
- `src/analyze_gatebench.py`, `src/analyze_extended.py`: tables and figures.
- `results/`: raw executions, aggregates, provenance manifest, and JSON summaries.
- `protocols/`: frozen real-fault procedure and unexecuted independent-annotation protocol.
- `paper/`: anonymous FSE manuscript source.

## Data and anonymity

Raw MRI data are not redistributed. They are available from the figshare record cited in the paper. The review artifact contains no author name, affiliation, ORCID, identifying repository URL, or acknowledgement. Public-project developer identities in immutable third-party citations do not identify the submitting author.

## License status

The review package is supplied for evaluation. The author must select an explicit public-release license before archival publication; see `LICENSE_PENDING.md`.
