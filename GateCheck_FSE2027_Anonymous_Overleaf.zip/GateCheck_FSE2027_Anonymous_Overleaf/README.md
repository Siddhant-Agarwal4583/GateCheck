# GateCheck — FSE 2027 anonymous manuscript source

This directory is the double-anonymous Overleaf-ready source. Its first line is the exact FSE 2027 class declaration:

```tex
\documentclass[acmsmall,screen,review,anonymous]{acmart}
```

Upload every file and the `figures` folder to a blank Overleaf project, then set `main.tex` as the main document and pdfLaTeX as the compiler. The bundled `acmart.cls` and `ACM-Reference-Format.bst` make the source self-contained; Overleaf's installed versions may also be used.

Local build:

```bash
latexmk -pdf -interaction=nonstopmode -halt-on-error main.tex
```

Do not add author names, affiliations, acknowledgements, ORCID identifiers, or an identifying repository URL to the review version. The sole-author metadata is maintained separately and is not part of this anonymous bundle.

The generated PDF is 14 pages in review layout, including references and the reproducibility appendix. The FSE 2027 limit is 18 pages of text/figures plus 4 pages of references. The mandatory `Data Availability` section follows the Conclusion.
